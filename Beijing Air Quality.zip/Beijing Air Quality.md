### Beijing Air Quality
Author: Gustavo Venturi

Date: 2021-01-21

Title: Beijing PM2.5 Data Dataset

Description: Estimative the PM2.5 particles behavior based on its answer to other 
parameters (how other parameters affect the PM2.5 particles) 


```python
#install libs
#!pip install pandas
#!pip install BeautifulSoup4
#!pip install seaborn
!pip install sklearn
```

    Processing c:\users\gusta\appdata\local\pip\cache\wheels\22\0b\40\fd3f795caaa1fb4c6cb738bc1f56100be1e57da95849bfc897\sklearn-0.0-py2.py3-none-any.whl
    Requirement already satisfied: scikit-learn in c:\programdata\anaconda3\lib\site-packages (from sklearn) (0.23.2)
    Requirement already satisfied: threadpoolctl>=2.0.0 in c:\programdata\anaconda3\lib\site-packages (from scikit-learn->sklearn) (2.1.0)
    Requirement already satisfied: scipy>=0.19.1 in c:\programdata\anaconda3\lib\site-packages (from scikit-learn->sklearn) (1.5.2)
    Requirement already satisfied: numpy>=1.13.3 in c:\programdata\anaconda3\lib\site-packages (from scikit-learn->sklearn) (1.19.2)
    Requirement already satisfied: joblib>=0.11 in c:\programdata\anaconda3\lib\site-packages (from scikit-learn->sklearn) (0.17.0)
    Installing collected packages: sklearn
    Successfully installed sklearn-0.0
    


```python
import pandas as pd
from urllib.request import urlopen
from bs4 import BeautifulSoup
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm
import seaborn as sns
from sklearn import datasets, ensemble
from sklearn.inspection import permutation_importance
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_percentage_error
```


    ---------------------------------------------------------------------------

    ImportError                               Traceback (most recent call last)

    <ipython-input-41-4a8818afb989> in <module>
         10 from sklearn.metrics import mean_squared_error
         11 from sklearn.model_selection import train_test_split
    ---> 12 from sklearn.metrics import mean_absolute_percentage_error
    

    ImportError: cannot import name 'mean_absolute_percentage_error' from 'sklearn.metrics' (C:\ProgramData\Anaconda3\lib\site-packages\sklearn\metrics\__init__.py)


#### Web scrapping from UCI page


```python
url = 'https://archive.ics.uci.edu/ml/datasets/Beijing+PM2.5+Data'

html = urlopen(url)
bs = BeautifulSoup(html,'html.parser')
dwloadUrl = bs.find_all('a', href=True)

dwloadUrl

dl = []
for link in dwloadUrl:
    u = str(link) 
    if u.find('Data Folder') > 0:
        dl.append(link['href'])

dl = str(dl[0]).replace('..', 'https://archive.ics.uci.edu/ml') #found url to direct to repository

html = urlopen(dl)
bs = BeautifulSoup(html,'html.parser')
dwloadUrl = bs.find_all('a', href=True)

dlFile = []
i = 0
for link in dwloadUrl:
    u = str(link)
    #x = u.find('.csv')    
    if u.find('.csv') > 0:
        dlFile.append(link['href'])

dl = dl + str(dlFile[0])
```

#### Reading data


```python
df = pd.read_csv(dl)
```

#### Data analysis

The polluant **PM 2.5** which is particulate matter suspended in air with a size smaller than or equal to 2.5 μm.  

High concentrations of PM 2.5 can cause severe damage to the respiratory system.

According to the WHO (World Health Organization), the tolerable limits of these particles are: 

» Annual average: 10 μg/m³  

» Average 24 hours: 25 μg/m³

Source: https://apps.who.int/iris/bitstream/handle/10665/69477/WHO_SDE_PHE_OEH_06.02_eng.pdf;jsessionid=4BA80EAA77F8DD1CC0C6798EADBF1C8F?sequence=1


```python
plt.plot(df['pm2.5'],'-', )
plt.xlabel('registers')
plt.ylabel('pm2.5')
plt.axhline(y=10,color='r',linestyle='dotted')
plt.axhline(y=25,color='r',linestyle='-')
plt.title('Evolution by entry of pm2.5')
plt.show();
```


    
![png](output_9_0.png)
    


The chart above shows all inputs of pm 2.5 collected from 2010 until 2014.
Red line is limit torelable by WHO.


```python
maximus = pd.Series(df['pm2.5'],name='pm2.5').max()
minimus = pd.Series(df['pm2.5'],name='pm2.5').min()

x_axis = np.arange(minimus, maximus, 10)

mean = pd.Series(df['pm2.5'],name='pm2.5').mean()
sd = pd.Series(df['pm2.5'],name='pm2.5').std()

plt.plot(x_axis, norm.pdf(x_axis,mean,sd))
plt.title('Normal Distribution pm2.5')
plt.axvline(x=mean,color='r',linestyle='-')
plt.axvline(x=mean+sd,color='r',linestyle='-.')
plt.axvline(x=mean+(sd*2),color='r',linestyle='dotted')
plt.axvline(x=mean-sd,color='r',linestyle='-.')
plt.axvline(x=mean-(sd*2),color='r',linestyle='dotted')
plt.show()
```


    
![png](output_11_0.png)
    


Above there are gaussian and standard deviations.
The average is ```98.6``` and standard deviation is ```92.05```.


```python
print(f'Average: {mean} and Standard Deviation: {sd}.') 
```

    Average: 98.61321455085375 and Standard Deviation: 92.05038718924138.
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>No</th>
      <th>year</th>
      <th>month</th>
      <th>day</th>
      <th>hour</th>
      <th>pm2.5</th>
      <th>DEWP</th>
      <th>TEMP</th>
      <th>PRES</th>
      <th>Iws</th>
      <th>Is</th>
      <th>Ir</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>43824.000000</td>
      <td>43824.000000</td>
      <td>43824.000000</td>
      <td>43824.000000</td>
      <td>43824.000000</td>
      <td>41757.000000</td>
      <td>43824.000000</td>
      <td>43824.000000</td>
      <td>43824.000000</td>
      <td>43824.000000</td>
      <td>43824.000000</td>
      <td>43824.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>21912.500000</td>
      <td>2012.000000</td>
      <td>6.523549</td>
      <td>15.727820</td>
      <td>11.500000</td>
      <td>98.613215</td>
      <td>1.817246</td>
      <td>12.448521</td>
      <td>1016.447654</td>
      <td>23.889140</td>
      <td>0.052734</td>
      <td>0.194916</td>
    </tr>
    <tr>
      <th>std</th>
      <td>12651.043435</td>
      <td>1.413842</td>
      <td>3.448572</td>
      <td>8.799425</td>
      <td>6.922266</td>
      <td>92.050387</td>
      <td>14.433440</td>
      <td>12.198613</td>
      <td>10.268698</td>
      <td>50.010635</td>
      <td>0.760375</td>
      <td>1.415867</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>2010.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-40.000000</td>
      <td>-19.000000</td>
      <td>991.000000</td>
      <td>0.450000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>10956.750000</td>
      <td>2011.000000</td>
      <td>4.000000</td>
      <td>8.000000</td>
      <td>5.750000</td>
      <td>29.000000</td>
      <td>-10.000000</td>
      <td>2.000000</td>
      <td>1008.000000</td>
      <td>1.790000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>21912.500000</td>
      <td>2012.000000</td>
      <td>7.000000</td>
      <td>16.000000</td>
      <td>11.500000</td>
      <td>72.000000</td>
      <td>2.000000</td>
      <td>14.000000</td>
      <td>1016.000000</td>
      <td>5.370000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>32868.250000</td>
      <td>2013.000000</td>
      <td>10.000000</td>
      <td>23.000000</td>
      <td>17.250000</td>
      <td>137.000000</td>
      <td>15.000000</td>
      <td>23.000000</td>
      <td>1025.000000</td>
      <td>21.910000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>43824.000000</td>
      <td>2014.000000</td>
      <td>12.000000</td>
      <td>31.000000</td>
      <td>23.000000</td>
      <td>994.000000</td>
      <td>28.000000</td>
      <td>42.000000</td>
      <td>1046.000000</td>
      <td>585.600000</td>
      <td>27.000000</td>
      <td>36.000000</td>
    </tr>
  </tbody>
</table>
</div>



The dataframe above describes our dataset feature by feature.


```python
dfYear = df[['year','month','pm2.5']]
dfYear['Period'] = (dfYear['year'])*100+(dfYear['month'])
dfYear = dfYear.drop(columns=['year','month'])
dfYearM = dfYear.groupby(by=['Period']).mean();
height = dfYearM['pm2.5']
x_pos = np.arange(60)
plt.bar(x_pos, height)
plt.xlabel('months')
plt.ylabel('pm2.5')
plt.title('Monthly average pm2.5')
plt.axhline(y=10,color='r',linestyle='dotted')
plt.axhline(y=25,color='r',linestyle='-')
plt.show()
```

    <ipython-input-16-a25e9b289c30>:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      dfYear['Period'] = (dfYear['year'])*100+(dfYear['month'])
    


    
![png](output_16_1.png)
    


The chart above shows average by month of pm2.5.
This chart shows some seasonality in data.


```python
dfHour = df[['hour','month','pm2.5']]
dfHour = dfHour.groupby(by=['hour','month']).mean()
#dfHour

height = dfHour['pm2.5']
x_pos = np.arange(288)
plt.bar(x_pos, height)
plt.xlabel('hours')
plt.ylabel('pm2.5')
plt.title('Hourly average per month pm2.5')
plt.axhline(y=10,color='r',linestyle='dotted')
plt.axhline(y=25,color='r',linestyle='-')
plt.show()
```


    
![png](output_18_0.png)
    


This chart shows evolution inside months there hourly seasonality.

Below we make a correlation plot with all features to identify which of them cause some influence.


```python
sns.pairplot(df);
```




    <seaborn.axisgrid.PairGrid at 0x1c456aba310>




    
![png](output_21_1.png)
    



```python
corr = df.corr()
sns.heatmap(corr, 
            linewidths=1,
            xticklabels=corr.columns.values,
            yticklabels=corr.columns.values);

```


    
![png](output_22_0.png)
    


All these mini graphs show us in a visual way the distribution and correlation between the data.
Heatmap show the DEWP (Dew Point) and Iws (Cumulated Wind Speed) are important features.



```python
#features more influents with pm2.5
#Dew Point correlation 0.17423
#Iws (Cumulated wind speed) correlation -0.247784
```


```python
dfMostInf = df[['pm2.5','DEWP','Iws']]

plt.scatter(dfMostInf['pm2.5'], dfMostInf['DEWP'] )
plt.xlabel('pm2.5')
plt.ylabel('Dew Point (ºC)')
plt.title('Comparisson between pm2.5 and Dew Point')
plt.axvline(x=10,color='r',linestyle='dotted')
plt.axvline(x=25,color='r',linestyle='-')
plt.show()
```


    
![png](output_25_0.png)
    


Airborne particles can be captured as condensation nuclei as dew condenses, whereas gases or liquid particles might dissolve into the dewdrops. Thus, dew formation can actually help purify urban air, and dew is recognized as the sink of nighttime moisture and near-surface particulate matter (e.g., PM2.5 and PM10).

Source: https://www.hindawi.com/journals/amete/2017/3514743/


```python
plt.scatter(dfMostInf['pm2.5'], dfMostInf['Iws'] )
plt.xlabel('pm2.5')
plt.ylabel('Cumulated Wind Speed (m/s)')
plt.title('Comparisson between pm2.5 and Cumulated Wind Speed')
plt.axvline(x=10,color='r',linestyle='dotted')
plt.axvline(x=25,color='r',linestyle='-')
plt.show()
```


    
![png](output_27_0.png)
    


More wind register less particules suspended in air.
